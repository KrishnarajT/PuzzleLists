import pygame

"""
COPY MATERIAL

    lost_Loop = False
    while lost_Loop:
        WIN.blit( PLAY_IMAGE, ORIGIN )
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                play_Loop = False
"""
